package com.fdmgroup.userregistration;

import java.io.File;
import java.io.IOException;

import org.junit.AfterClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ FileWriteCommandTest.class, RegistrationControllerTest.class, UserFactoryTest.class, UserTest.class })

public class AllTests { 
	 
	@AfterClass
	public static void delete() throws IOException {
		String savedData = "./user_information.txt";
		File deleteFile = new File(savedData);
		deleteFile.delete();
		System.out.println("system cleaning-up");
		deleteFile.createNewFile();
		System.out.println("system cleaned");
	}
	
}